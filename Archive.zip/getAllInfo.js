document.getElementsByClassName('songTitle')[0].text + ";" + 
document.getElementsByClassName('artistSummary')[0].text + ";" +
document.getElementsByClassName('albumTitle')[0].text + ";" +
document.getElementsByClassName('playerBarArt')[0].src