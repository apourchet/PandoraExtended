if (document.getElementsByClassName("playButton")[0].style['display'] === 'none') {
	document.getElementsByClassName("pauseButton")[0].click()
} else {
	document.getElementsByClassName("playButton")[0].click()
}